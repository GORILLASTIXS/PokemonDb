﻿using CSS_API.DemoApp.Domain;
using Newtonsoft.Json;
using RestSharp;
using System;
using System.Collections.Generic;
using System.Windows.Forms;
using System.Linq;
using System.Drawing;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.IO;

namespace CSS_API.DemoApp
{
    public partial class frmMain : Form
    {
        public OAuthToken _Token { get; set; }

        public frmMain()
        {
            InitializeComponent();
        }

        private bool ValidateSettings()
        {
            errorProvider1.Clear();

            if (String.IsNullOrEmpty(txtBaseURL.Text))
            {
                MessageBox.Show("Base URL cannot be empty.", "Demo App", MessageBoxButtons.OK, MessageBoxIcon.Error);
                errorProvider1.SetError(txtBaseURL, "Base URL cannot be empty.");
                return false;
            }

            if (String.IsNullOrEmpty(txtClientId.Text))
            {
                MessageBox.Show("Client Id cannot be empty.", "Demo App", MessageBoxButtons.OK, MessageBoxIcon.Error);
                errorProvider1.SetError(txtClientId, "Client Id cannot be empty.");
                return false;
            }

            if (String.IsNullOrEmpty(txtClientSecret.Text))
            {
                MessageBox.Show("Client Secret cannot be empty.", "Demo App", MessageBoxButtons.OK, MessageBoxIcon.Error);
                errorProvider1.SetError(txtClientSecret, "Client Secret cannot be empty.");
                return false;
            }

            return true;
        }

        private void btnGETSchema_Click(object sender, EventArgs e)
        {
            try
            {
                // CSSAPI/v2 is the route to the four endpoints (SCHEMA, SEELCT, UPDATE and ADD) so you need to keep it
                // Next segment is the entity name segment, for example tblContracts becomes Contracts and tblCustomers become Customers
                // and for user-defined entities tbl_u_UserDefinedTable becomes u_UserDefinedTable
                var client = new RestClient($"{txtBaseURL.Text}/CSSAPI/v2/Contracts/Schema");

                var request = new RestRequest(Method.POST);

                request.AddHeader("content-type", "application/x-www-form-urlencoded");
                request.AddHeader("Authorization", $"Bearer {_Token.AccessToken}");

                IRestResponse response = client.Execute(request);

                txtGETSchemaResult.Text = JsonHelper.FormatJson(response.Content);

                List<SchemaInfo> infoList = JsonConvert.DeserializeObject<List<SchemaInfo>>(response.Content);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Demo App", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private async void btnAuthenticate_Click(object sender, EventArgs e)
        {
            try
            {
                if (!ValidateSettings())
                {
                    return;
                }

                var client = new RestClient($"{txtBaseURL.Text}/oauth/token");
                var request = new RestRequest(Method.POST);

                request.AddHeader("content-type", "application/x-www-form-urlencoded");
                request.AddParameter("application/x-www-form-urlencoded",
                                    $"grant_type=client_credentials&client_id={txtClientId.Text}&client_secret={txtClientSecret.Text}",
                                     ParameterType.RequestBody);

                IRestResponse response = client.Execute(request);

                _Token = JsonConvert.DeserializeObject<OAuthToken>(response.Content);

                txtAuthenticateResponse.Text = JsonHelper.FormatJson(response.Content);
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message, "Demo App", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnPOSTRefresh_Click(object sender, EventArgs e)
        {
            try
            {
                var client = new RestClient($"{txtBaseURL.Text}/oauth/token");
                var request = new RestRequest(Method.POST);

                request.AddHeader("content-type", "application/x-www-form-urlencoded");
                request.AddParameter("application/x-www-form-urlencoded",
                                    $"grant_type=refresh_token&client_id={txtClientId.Text}&refresh_token={_Token.RefreshToken}",
                                    ParameterType.RequestBody);

                IRestResponse response = client.Execute(request);

                _Token = JsonConvert.DeserializeObject<OAuthToken>(response.Content);

                txtPOSTRefreshResponse.Text = JsonHelper.FormatJson(response.Content);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Demo App", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnPOSTSelect_Click(object sender, EventArgs e)
        {
            try
            {
                List<SelectField> fields = new List<SelectField>();

                // ******** SELECT TAG ********
                // To have it as SELECT * then just pass empty collection
                fields.Add(new SelectField() { Attribute = "Contract_ID", Alias = "Id" });
                fields.Add(new SelectField() { Attribute = "Contract_Title", Alias = "Title" });

                // ******** WHERE CLAUSE TAG ********
                // If you have no clause then pass null
                ClauseRule clause = new ClauseRule();

                clause.Condition = "AND";

                // This will generate (DateUpdated => 'Today Date' AND Contract_Title LIKE '%Cobble%')
                List<ClauseRule> subRules = new List<ClauseRule>();

                /* LIST OF OPERATORS
                    is_not_null
                    is_null
                    not_ends_with
                    ends_with
                    not_contains
                    contains
                    not_begins_with
                    begins_with
                    greater_or_equal
                    greater
                    less_or_equal
                    less
                    not_between
                    between
                    not_equal
                    is_not_empty
                    is_empty
                    equal
                    not_in
                    in
                 */

                /* LIST OF TYPES
                   integer
                   double
                   string
                   datetime
                   boolean
                */

                subRules.Add(new ClauseRule()
                {
                    Id = "ContractGUID",
                    Field = "ContractGUID",
                    Type = "string",
                    Operator = "equal", // <=
                    Value = "3e1b694b-d801-45be-ae70-eecef3c4b67c"
                });

                /*subRules.Add(new ClauseRule()
                {
                    Id = "Contract_Title",
                    Field = "Contract_Title",
                    Type = "string",
                    Operator = "contains",
                    Value = "Cobble"
                });*/

                clause.Rules = subRules;

                // ******** ORDER BY TAG ********

                OrderBy orderBy = new OrderBy()
                {
                    Fields = (new string[] { "Contract_ID" }).ToList(),
                    Direction = "ASC"
                };

                var query = new SelectQuery()
                {
                    Fields = fields,
                    Clause = clause,
                    OrderByTag = orderBy,
                    // ******** PAGING ********
                    StartIndex = 0,
                    Length = 10
                };

                var client = new RestClient($"{txtBaseURL.Text}/CSSAPI/v2/Contracts/Get");
                var request = new RestRequest(Method.POST);
                string querySerialized = JsonConvert.SerializeObject(query);

                request.AddHeader("content-type", "application/json");
                request.AddHeader("Authorization", $"Bearer {_Token.AccessToken}");
                request.AddJsonBody(querySerialized);

                IRestResponse response = client.Execute(request);

                txtPOSTSelectResponse.Text = JsonHelper.FormatJson(response.Content);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Demo App", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnPOSTUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                // ******** WHERE CLAUSE TAG ********
                ClauseRule clause = new ClauseRule();

                clause.Condition = "AND";

                // This will generate (VendorID = 168)
                List<ClauseRule> subRules = new List<ClauseRule>();

                subRules.Add(new ClauseRule()
                {
                    Id = "Transaction_ID",
                    Field = "Transaction_ID",
                    Type = "int",
                    Operator = "equal",
                    Value = 1764
                });

                clause.Rules = subRules;

                // ******** UPDATE TUPLES (attribute, value) ********
                List<UpdateTuple> tuples = new List<UpdateTuple>();

                tuples.Add(new UpdateTuple()
                {
                    Name = "Debit",
                    Value = (decimal)602.17
                });

                var update = new UpdateRequest()
                {
                    Clause = clause,
                    Tuples = tuples,
                    TriggerWorkflow = false
                };

                var client = new RestClient($"{txtBaseURL.Text}/CSSAPI/v2/ContractFinancials/Update");
                var request = new RestRequest(Method.POST);
                string querySerialized = JsonConvert.SerializeObject(update);

                request.AddHeader("content-type", "application/json");
                request.AddHeader("Authorization", $"Bearer {_Token.AccessToken}");
                request.AddJsonBody(querySerialized);

                IRestResponse response = client.Execute(request);

                txtPOSTUpdateResponse.Text = JsonHelper.FormatJson(response.Content);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Demo App", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnPOSTInsert_Click(object sender, EventArgs e)
        {
            try
            {
                AddRequest addRequest = new AddRequest();

                addRequest.Tuples.Add(new AddTuple()
                {
                    Name = "Debit",
                    Value = (decimal)602.17
                });

                var client = new RestClient($"{txtBaseURL.Text}/CSSAPI/v2/ContractFinancials/Add");
                var request = new RestRequest(Method.POST);
                string querySerialized = JsonConvert.SerializeObject(addRequest);

                request.AddHeader("content-type", "application/json");
                request.AddHeader("Authorization", $"Bearer {_Token.AccessToken}");
                request.AddJsonBody(querySerialized);

                IRestResponse response = client.Execute(request);

                txtPOSTAddResponse.Text = JsonHelper.FormatJson(response.Content);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Demo App", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void tabControl1_DrawItem(object sender, DrawItemEventArgs e)
        {
            Color color = Color.Transparent;
            Pen pen = Pens.Transparent;

            if (e.Index == 6 || e.Index == 7)
            {
                color = Color.LightGreen;
                pen = Pens.LightGreen;
            }

            using (Brush br = new SolidBrush(color))
            {
                e.Graphics.FillRectangle(br, e.Bounds);
                SizeF sz = e.Graphics.MeasureString(tabControl1.TabPages[e.Index].Text, e.Font);
                e.Graphics.DrawString(tabControl1.TabPages[e.Index].Text, e.Font, Brushes.Black, e.Bounds.Left + (e.Bounds.Width - sz.Width) / 2, e.Bounds.Top + (e.Bounds.Height - sz.Height) / 2 + 1);

                Rectangle rect = e.Bounds;
                rect.Offset(0, 1);
                rect.Inflate(0, -1);
                e.Graphics.DrawRectangle(pen, rect);
                e.DrawFocusRectangle();
            }
        }

        private async void btnPostMimeSelect_Click(object sender, EventArgs e)
        {
            // Asking user for folder to save file
            if (folderBrowserDialog1.ShowDialog() != DialogResult.OK)
            {
                return;
            }

            string path = folderBrowserDialog1.SelectedPath;

            List<SelectField> fields = new List<SelectField>();

            ClauseRule clause = new ClauseRule();

            clause.Condition = "AND";

            // This will generate (ContractID = ?)
            List<ClauseRule> subRules = new List<ClauseRule>();

            subRules.Add(new ClauseRule()
            {
                Id = "ContractID",
                Field = "ContractID",
                Type = "int",
                Operator = "equal",
                Value = 1
            });

            clause.Rules = subRules;

            // Querying all columns from entity without filter, ofcourse 1 row will return since thats what server only allow in case of file download
            var query = new SelectQuery()
            {
                Fields = fields,
                Clause = clause,
                // ******** PAGING ********
                StartIndex = 0,
                Length = 100
            };

            HttpClient client = new HttpClient();

            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
            client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", _Token.AccessToken);

            var stringcontent = new StringContent(JsonConvert.SerializeObject(query), Encoding.UTF8, "application/json");

            // Post the request
            HttpResponseMessage response = await client.PostAsync($"{txtBaseURL.Text}/CSSAPI/v2/Files/{txtMIMEEntityName.Text}/Download", stringcontent);

            if (response.StatusCode != System.Net.HttpStatusCode.OK)
            {
                MessageBox.Show("Response sent back error code.", "Demo App", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            // response is MIME content
            var mimeContent = await response.Content.ReadAsMultipartAsync();

            var json = await mimeContent.Contents[1].ReadAsStringAsync(); // JSON data
            var streamContent = await mimeContent.Contents[0].ReadAsStreamAsync(); // Stream to the byte[]

            // Following is to extract filename from headers
            var header = response.Content.Headers.Where(x => x.Key == "Content-Disposition").FirstOrDefault();
            string filename = header.Value.ToArray()[0].ToString().Replace("attachment; filename=", "").Replace("\"", "");

            // Write file to disk
            using (FileStream outputFileStream = new FileStream(Path.Combine(path, filename), FileMode.Create))
            {
                streamContent.CopyTo(outputFileStream);
            }

            txtPOSTMIMEResponse.Text = JsonHelper.FormatJson(json);
        }

        private async void btnPostMimeInsert_Click(object sender, EventArgs e)
        {
            if (openFileDialog1.ShowDialog() != DialogResult.OK)
            {
                return;
            }

            string filepath = openFileDialog1.FileName;

            HttpClient client = new HttpClient();
            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
            client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", _Token.AccessToken);
            client.DefaultRequestHeaders.TransferEncodingChunked = true;

            var mimeContent = new MultipartFormDataContent();

            var addRequest = new AddRequest();

            addRequest.Tuples.Add(new AddTuple()
            {
                Name = "Keywords",
                Value = "Added Via Demo Application"
            });
            addRequest.Tuples.Add(new AddTuple()
            {
                Name = "ContractID",
                Value = 1
            });
            addRequest.Tuples.Add(new AddTuple()
            {
                Name = "EmployeeID",
                Value = 335
            });
            addRequest.Tuples.Add(new AddTuple()
            {
                Name = "ContractFile",
                Value = null
            });
            addRequest.Tuples.Add(new AddTuple()
            {
                Name = "FileName",
                Value = Path.GetFileName(filepath)
            });
            addRequest.Tuples.Add(new AddTuple()
            {
                Name = "FileType",
                Value = Path.GetExtension(filepath)
            });

            string querySerialized = JsonConvert.SerializeObject(addRequest);
            FileStream filestream = File.OpenRead(filepath);
            var dataContent = new StreamContent(filestream);

            mimeContent.Add(dataContent, "attachment", Path.GetFileName(filepath));
            mimeContent.Add(new StringContent(querySerialized, Encoding.UTF8, "application/json"));

            HttpResponseMessage response = await client.PostAsync($"{txtBaseURL.Text}/CSSAPI/v2/Files/{txtMIMEInsertEntityName.Text}/Upload", mimeContent);
            response.EnsureSuccessStatusCode();

            txtPOSTINSERTMIMEResponse.Text = JsonHelper.FormatJson(await response.Content.ReadAsStringAsync());
        }
    }
}
