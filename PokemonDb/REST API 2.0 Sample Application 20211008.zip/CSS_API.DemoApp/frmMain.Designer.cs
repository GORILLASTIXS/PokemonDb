﻿namespace CSS_API.DemoApp
{
    partial class frmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmMain));
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.panel2 = new System.Windows.Forms.Panel();
            this.btnAuthenticate = new System.Windows.Forms.Button();
            this.txtAuthenticateResponse = new System.Windows.Forms.TextBox();
            this.tabPage6 = new System.Windows.Forms.TabPage();
            this.panel4 = new System.Windows.Forms.Panel();
            this.btnPOSTRefresh = new System.Windows.Forms.Button();
            this.txtPOSTRefreshResponse = new System.Windows.Forms.TextBox();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.panel1 = new System.Windows.Forms.Panel();
            this.txtGETSchemaResult = new System.Windows.Forms.TextBox();
            this.btnGETSchema = new System.Windows.Forms.Button();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.panel3 = new System.Windows.Forms.Panel();
            this.txtPOSTSelectResponse = new System.Windows.Forms.TextBox();
            this.btnPOSTSelect = new System.Windows.Forms.Button();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.panel5 = new System.Windows.Forms.Panel();
            this.txtPOSTUpdateResponse = new System.Windows.Forms.TextBox();
            this.btnPOSTUpdate = new System.Windows.Forms.Button();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.panel6 = new System.Windows.Forms.Panel();
            this.txtPOSTAddResponse = new System.Windows.Forms.TextBox();
            this.btnPOSTInsert = new System.Windows.Forms.Button();
            this.tabPage7 = new System.Windows.Forms.TabPage();
            this.panel7 = new System.Windows.Forms.Panel();
            this.label5 = new System.Windows.Forms.Label();
            this.txtMIMEEntityName = new System.Windows.Forms.TextBox();
            this.txtPOSTMIMEResponse = new System.Windows.Forms.TextBox();
            this.btnPostMimeSelect = new System.Windows.Forms.Button();
            this.tabPage8 = new System.Windows.Forms.TabPage();
            this.panel8 = new System.Windows.Forms.Panel();
            this.txtPOSTINSERTMIMEResponse = new System.Windows.Forms.TextBox();
            this.btnPostMimeInsert = new System.Windows.Forms.Button();
            this.panel9 = new System.Windows.Forms.Panel();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.txtClientSecret = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtClientId = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtBaseURL = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.errorProvider1 = new System.Windows.Forms.ErrorProvider(this.components);
            this.folderBrowserDialog1 = new System.Windows.Forms.FolderBrowserDialog();
            this.label4 = new System.Windows.Forms.Label();
            this.txtMIMEInsertEntityName = new System.Windows.Forms.TextBox();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.tabControl1.SuspendLayout();
            this.tabPage5.SuspendLayout();
            this.panel2.SuspendLayout();
            this.tabPage6.SuspendLayout();
            this.panel4.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.panel1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.panel5.SuspendLayout();
            this.tabPage4.SuspendLayout();
            this.panel6.SuspendLayout();
            this.tabPage7.SuspendLayout();
            this.panel7.SuspendLayout();
            this.tabPage8.SuspendLayout();
            this.panel8.SuspendLayout();
            this.panel9.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage5);
            this.tabControl1.Controls.Add(this.tabPage6);
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Controls.Add(this.tabPage7);
            this.tabControl1.Controls.Add(this.tabPage8);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.DrawMode = System.Windows.Forms.TabDrawMode.OwnerDrawFixed;
            this.tabControl1.Location = new System.Drawing.Point(0, 99);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(799, 398);
            this.tabControl1.TabIndex = 0;
            this.tabControl1.DrawItem += new System.Windows.Forms.DrawItemEventHandler(this.tabControl1_DrawItem);
            // 
            // tabPage5
            // 
            this.tabPage5.BackColor = System.Drawing.Color.Transparent;
            this.tabPage5.Controls.Add(this.panel2);
            this.tabPage5.Location = new System.Drawing.Point(4, 22);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage5.Size = new System.Drawing.Size(791, 372);
            this.tabPage5.TabIndex = 4;
            this.tabPage5.Text = "Authenticate";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.Control;
            this.panel2.Controls.Add(this.btnAuthenticate);
            this.panel2.Controls.Add(this.txtAuthenticateResponse);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.Location = new System.Drawing.Point(3, 3);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(785, 366);
            this.panel2.TabIndex = 0;
            // 
            // btnAuthenticate
            // 
            this.btnAuthenticate.Location = new System.Drawing.Point(17, 16);
            this.btnAuthenticate.Name = "btnAuthenticate";
            this.btnAuthenticate.Size = new System.Drawing.Size(113, 42);
            this.btnAuthenticate.TabIndex = 3;
            this.btnAuthenticate.Text = "Authenticate";
            this.btnAuthenticate.UseVisualStyleBackColor = true;
            this.btnAuthenticate.Click += new System.EventHandler(this.btnAuthenticate_Click);
            // 
            // txtAuthenticateResponse
            // 
            this.txtAuthenticateResponse.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtAuthenticateResponse.Location = new System.Drawing.Point(17, 64);
            this.txtAuthenticateResponse.Multiline = true;
            this.txtAuthenticateResponse.Name = "txtAuthenticateResponse";
            this.txtAuthenticateResponse.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txtAuthenticateResponse.Size = new System.Drawing.Size(750, 287);
            this.txtAuthenticateResponse.TabIndex = 2;
            // 
            // tabPage6
            // 
            this.tabPage6.Controls.Add(this.panel4);
            this.tabPage6.Location = new System.Drawing.Point(4, 22);
            this.tabPage6.Name = "tabPage6";
            this.tabPage6.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage6.Size = new System.Drawing.Size(791, 372);
            this.tabPage6.TabIndex = 5;
            this.tabPage6.Text = "Refresh Token";
            this.tabPage6.UseVisualStyleBackColor = true;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.SystemColors.Control;
            this.panel4.Controls.Add(this.btnPOSTRefresh);
            this.panel4.Controls.Add(this.txtPOSTRefreshResponse);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel4.Location = new System.Drawing.Point(3, 3);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(785, 366);
            this.panel4.TabIndex = 1;
            // 
            // btnPOSTRefresh
            // 
            this.btnPOSTRefresh.Location = new System.Drawing.Point(17, 16);
            this.btnPOSTRefresh.Name = "btnPOSTRefresh";
            this.btnPOSTRefresh.Size = new System.Drawing.Size(113, 42);
            this.btnPOSTRefresh.TabIndex = 3;
            this.btnPOSTRefresh.Text = "POST Refresh";
            this.btnPOSTRefresh.UseVisualStyleBackColor = true;
            this.btnPOSTRefresh.Click += new System.EventHandler(this.btnPOSTRefresh_Click);
            // 
            // txtPOSTRefreshResponse
            // 
            this.txtPOSTRefreshResponse.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtPOSTRefreshResponse.Location = new System.Drawing.Point(17, 64);
            this.txtPOSTRefreshResponse.Multiline = true;
            this.txtPOSTRefreshResponse.Name = "txtPOSTRefreshResponse";
            this.txtPOSTRefreshResponse.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txtPOSTRefreshResponse.Size = new System.Drawing.Size(750, 287);
            this.txtPOSTRefreshResponse.TabIndex = 2;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.panel1);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(791, 372);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Schema Call";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.Control;
            this.panel1.Controls.Add(this.txtGETSchemaResult);
            this.panel1.Controls.Add(this.btnGETSchema);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(3, 3);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(785, 366);
            this.panel1.TabIndex = 0;
            // 
            // txtGETSchemaResult
            // 
            this.txtGETSchemaResult.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtGETSchemaResult.Location = new System.Drawing.Point(18, 64);
            this.txtGETSchemaResult.Multiline = true;
            this.txtGETSchemaResult.Name = "txtGETSchemaResult";
            this.txtGETSchemaResult.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txtGETSchemaResult.Size = new System.Drawing.Size(750, 287);
            this.txtGETSchemaResult.TabIndex = 1;
            // 
            // btnGETSchema
            // 
            this.btnGETSchema.Location = new System.Drawing.Point(18, 16);
            this.btnGETSchema.Name = "btnGETSchema";
            this.btnGETSchema.Size = new System.Drawing.Size(113, 42);
            this.btnGETSchema.TabIndex = 0;
            this.btnGETSchema.Text = "GET Schema";
            this.btnGETSchema.UseVisualStyleBackColor = true;
            this.btnGETSchema.Click += new System.EventHandler(this.btnGETSchema_Click);
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.panel3);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(791, 372);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Select (Query) Call";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.SystemColors.Control;
            this.panel3.Controls.Add(this.txtPOSTSelectResponse);
            this.panel3.Controls.Add(this.btnPOSTSelect);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel3.Location = new System.Drawing.Point(3, 3);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(785, 366);
            this.panel3.TabIndex = 1;
            // 
            // txtPOSTSelectResponse
            // 
            this.txtPOSTSelectResponse.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtPOSTSelectResponse.Location = new System.Drawing.Point(18, 64);
            this.txtPOSTSelectResponse.Multiline = true;
            this.txtPOSTSelectResponse.Name = "txtPOSTSelectResponse";
            this.txtPOSTSelectResponse.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txtPOSTSelectResponse.Size = new System.Drawing.Size(750, 287);
            this.txtPOSTSelectResponse.TabIndex = 1;
            // 
            // btnPOSTSelect
            // 
            this.btnPOSTSelect.Location = new System.Drawing.Point(18, 16);
            this.btnPOSTSelect.Name = "btnPOSTSelect";
            this.btnPOSTSelect.Size = new System.Drawing.Size(113, 42);
            this.btnPOSTSelect.TabIndex = 0;
            this.btnPOSTSelect.Text = "POST Select";
            this.btnPOSTSelect.UseVisualStyleBackColor = true;
            this.btnPOSTSelect.Click += new System.EventHandler(this.btnPOSTSelect_Click);
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.panel5);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(791, 372);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Update Call";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.SystemColors.Control;
            this.panel5.Controls.Add(this.txtPOSTUpdateResponse);
            this.panel5.Controls.Add(this.btnPOSTUpdate);
            this.panel5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel5.Location = new System.Drawing.Point(3, 3);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(785, 366);
            this.panel5.TabIndex = 2;
            // 
            // txtPOSTUpdateResponse
            // 
            this.txtPOSTUpdateResponse.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtPOSTUpdateResponse.Location = new System.Drawing.Point(18, 64);
            this.txtPOSTUpdateResponse.Multiline = true;
            this.txtPOSTUpdateResponse.Name = "txtPOSTUpdateResponse";
            this.txtPOSTUpdateResponse.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txtPOSTUpdateResponse.Size = new System.Drawing.Size(750, 287);
            this.txtPOSTUpdateResponse.TabIndex = 1;
            // 
            // btnPOSTUpdate
            // 
            this.btnPOSTUpdate.Location = new System.Drawing.Point(18, 16);
            this.btnPOSTUpdate.Name = "btnPOSTUpdate";
            this.btnPOSTUpdate.Size = new System.Drawing.Size(113, 42);
            this.btnPOSTUpdate.TabIndex = 0;
            this.btnPOSTUpdate.Text = "POST Update";
            this.btnPOSTUpdate.UseVisualStyleBackColor = true;
            this.btnPOSTUpdate.Click += new System.EventHandler(this.btnPOSTUpdate_Click);
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.panel6);
            this.tabPage4.Location = new System.Drawing.Point(4, 22);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(791, 372);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "Insert Call";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.SystemColors.Control;
            this.panel6.Controls.Add(this.txtPOSTAddResponse);
            this.panel6.Controls.Add(this.btnPOSTInsert);
            this.panel6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel6.Location = new System.Drawing.Point(3, 3);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(785, 366);
            this.panel6.TabIndex = 0;
            // 
            // txtPOSTAddResponse
            // 
            this.txtPOSTAddResponse.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtPOSTAddResponse.Location = new System.Drawing.Point(17, 63);
            this.txtPOSTAddResponse.Multiline = true;
            this.txtPOSTAddResponse.Name = "txtPOSTAddResponse";
            this.txtPOSTAddResponse.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txtPOSTAddResponse.Size = new System.Drawing.Size(750, 287);
            this.txtPOSTAddResponse.TabIndex = 3;
            // 
            // btnPOSTInsert
            // 
            this.btnPOSTInsert.Location = new System.Drawing.Point(17, 15);
            this.btnPOSTInsert.Name = "btnPOSTInsert";
            this.btnPOSTInsert.Size = new System.Drawing.Size(113, 42);
            this.btnPOSTInsert.TabIndex = 2;
            this.btnPOSTInsert.Text = "POST Insert";
            this.btnPOSTInsert.UseVisualStyleBackColor = true;
            this.btnPOSTInsert.Click += new System.EventHandler(this.btnPOSTInsert_Click);
            // 
            // tabPage7
            // 
            this.tabPage7.Controls.Add(this.panel7);
            this.tabPage7.Location = new System.Drawing.Point(4, 22);
            this.tabPage7.Margin = new System.Windows.Forms.Padding(2);
            this.tabPage7.Name = "tabPage7";
            this.tabPage7.Padding = new System.Windows.Forms.Padding(2);
            this.tabPage7.Size = new System.Drawing.Size(791, 372);
            this.tabPage7.TabIndex = 6;
            this.tabPage7.Text = "MIME Select Call";
            this.tabPage7.UseVisualStyleBackColor = true;
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.SystemColors.Control;
            this.panel7.Controls.Add(this.label5);
            this.panel7.Controls.Add(this.txtMIMEEntityName);
            this.panel7.Controls.Add(this.txtPOSTMIMEResponse);
            this.panel7.Controls.Add(this.btnPostMimeSelect);
            this.panel7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel7.Location = new System.Drawing.Point(2, 2);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(787, 368);
            this.panel7.TabIndex = 1;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(158, 30);
            this.label5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(67, 13);
            this.label5.TabIndex = 9;
            this.label5.Text = "Entity Name:";
            // 
            // txtMIMEEntityName
            // 
            this.txtMIMEEntityName.Location = new System.Drawing.Point(228, 27);
            this.txtMIMEEntityName.Margin = new System.Windows.Forms.Padding(2);
            this.txtMIMEEntityName.Name = "txtMIMEEntityName";
            this.txtMIMEEntityName.Size = new System.Drawing.Size(226, 20);
            this.txtMIMEEntityName.TabIndex = 8;
            this.txtMIMEEntityName.Text = "ContractFiles";
            // 
            // txtPOSTMIMEResponse
            // 
            this.txtPOSTMIMEResponse.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtPOSTMIMEResponse.Location = new System.Drawing.Point(17, 63);
            this.txtPOSTMIMEResponse.Multiline = true;
            this.txtPOSTMIMEResponse.Name = "txtPOSTMIMEResponse";
            this.txtPOSTMIMEResponse.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txtPOSTMIMEResponse.Size = new System.Drawing.Size(752, 289);
            this.txtPOSTMIMEResponse.TabIndex = 3;
            // 
            // btnPostMimeSelect
            // 
            this.btnPostMimeSelect.Location = new System.Drawing.Point(17, 15);
            this.btnPostMimeSelect.Name = "btnPostMimeSelect";
            this.btnPostMimeSelect.Size = new System.Drawing.Size(120, 43);
            this.btnPostMimeSelect.TabIndex = 2;
            this.btnPostMimeSelect.Text = "POST MIME Select";
            this.btnPostMimeSelect.UseVisualStyleBackColor = true;
            this.btnPostMimeSelect.Click += new System.EventHandler(this.btnPostMimeSelect_Click);
            // 
            // tabPage8
            // 
            this.tabPage8.Controls.Add(this.panel8);
            this.tabPage8.Location = new System.Drawing.Point(4, 22);
            this.tabPage8.Margin = new System.Windows.Forms.Padding(2);
            this.tabPage8.Name = "tabPage8";
            this.tabPage8.Padding = new System.Windows.Forms.Padding(2);
            this.tabPage8.Size = new System.Drawing.Size(791, 372);
            this.tabPage8.TabIndex = 7;
            this.tabPage8.Text = "MIME Insert Call";
            this.tabPage8.UseVisualStyleBackColor = true;
            // 
            // panel8
            // 
            this.panel8.BackColor = System.Drawing.SystemColors.Control;
            this.panel8.Controls.Add(this.label4);
            this.panel8.Controls.Add(this.txtMIMEInsertEntityName);
            this.panel8.Controls.Add(this.txtPOSTINSERTMIMEResponse);
            this.panel8.Controls.Add(this.btnPostMimeInsert);
            this.panel8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel8.Location = new System.Drawing.Point(2, 2);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(787, 368);
            this.panel8.TabIndex = 1;
            // 
            // txtPOSTINSERTMIMEResponse
            // 
            this.txtPOSTINSERTMIMEResponse.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtPOSTINSERTMIMEResponse.Location = new System.Drawing.Point(17, 63);
            this.txtPOSTINSERTMIMEResponse.Multiline = true;
            this.txtPOSTINSERTMIMEResponse.Name = "txtPOSTINSERTMIMEResponse";
            this.txtPOSTINSERTMIMEResponse.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txtPOSTINSERTMIMEResponse.Size = new System.Drawing.Size(752, 289);
            this.txtPOSTINSERTMIMEResponse.TabIndex = 3;
            // 
            // btnPostMimeInsert
            // 
            this.btnPostMimeInsert.Location = new System.Drawing.Point(17, 15);
            this.btnPostMimeInsert.Name = "btnPostMimeInsert";
            this.btnPostMimeInsert.Size = new System.Drawing.Size(113, 42);
            this.btnPostMimeInsert.TabIndex = 2;
            this.btnPostMimeInsert.Text = "POST MIME Insert";
            this.btnPostMimeInsert.UseVisualStyleBackColor = true;
            this.btnPostMimeInsert.Click += new System.EventHandler(this.btnPostMimeInsert_Click);
            // 
            // panel9
            // 
            this.panel9.BackColor = System.Drawing.SystemColors.Control;
            this.panel9.Controls.Add(this.groupBox1);
            this.panel9.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel9.Location = new System.Drawing.Point(0, 0);
            this.panel9.Margin = new System.Windows.Forms.Padding(2);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(799, 99);
            this.panel9.TabIndex = 1;
            // 
            // groupBox1
            // 
            this.groupBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox1.Controls.Add(this.txtClientSecret);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.txtClientId);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.txtBaseURL);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Location = new System.Drawing.Point(9, 10);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(2);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(2);
            this.groupBox1.Size = new System.Drawing.Size(781, 84);
            this.groupBox1.TabIndex = 6;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Settings";
            // 
            // txtClientSecret
            // 
            this.txtClientSecret.Location = new System.Drawing.Point(406, 24);
            this.txtClientSecret.Margin = new System.Windows.Forms.Padding(2);
            this.txtClientSecret.Name = "txtClientSecret";
            this.txtClientSecret.Size = new System.Drawing.Size(226, 20);
            this.txtClientSecret.TabIndex = 11;
            this.txtClientSecret.Text = "C1B49B24-8D21-4FB1-A6AC-5FCCAB10AE61";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(332, 27);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(70, 13);
            this.label3.TabIndex = 10;
            this.label3.Text = "Client Secret:";
            // 
            // txtClientId
            // 
            this.txtClientId.Location = new System.Drawing.Point(74, 24);
            this.txtClientId.Margin = new System.Windows.Forms.Padding(2);
            this.txtClientId.Name = "txtClientId";
            this.txtClientId.Size = new System.Drawing.Size(226, 20);
            this.txtClientId.TabIndex = 9;
            this.txtClientId.Text = "2F9988CA-FB1C-4A9A-853D-F7C88F9E7CA1";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(22, 27);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(48, 13);
            this.label2.TabIndex = 8;
            this.label2.Text = "Client Id:";
            // 
            // txtBaseURL
            // 
            this.txtBaseURL.Location = new System.Drawing.Point(74, 47);
            this.txtBaseURL.Margin = new System.Windows.Forms.Padding(2);
            this.txtBaseURL.Name = "txtBaseURL";
            this.txtBaseURL.Size = new System.Drawing.Size(226, 20);
            this.txtBaseURL.TabIndex = 7;
            this.txtBaseURL.Text = "http://localhost:61788/";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 50);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(59, 13);
            this.label1.TabIndex = 6;
            this.label1.Text = "Base URL:";
            // 
            // errorProvider1
            // 
            this.errorProvider1.ContainerControl = this;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(157, 30);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(67, 13);
            this.label4.TabIndex = 11;
            this.label4.Text = "Entity Name:";
            // 
            // txtMIMEInsertEntityName
            // 
            this.txtMIMEInsertEntityName.Location = new System.Drawing.Point(227, 27);
            this.txtMIMEInsertEntityName.Margin = new System.Windows.Forms.Padding(2);
            this.txtMIMEInsertEntityName.Name = "txtMIMEInsertEntityName";
            this.txtMIMEInsertEntityName.Size = new System.Drawing.Size(226, 20);
            this.txtMIMEInsertEntityName.TabIndex = 10;
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(799, 497);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.panel9);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "frmMain";
            this.Text = "CSS RESTfull API - DemoApp";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.tabControl1.ResumeLayout(false);
            this.tabPage5.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.tabPage6.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.tabPage1.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.tabPage4.ResumeLayout(false);
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.tabPage7.ResumeLayout(false);
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            this.tabPage8.ResumeLayout(false);
            this.panel8.ResumeLayout(false);
            this.panel8.PerformLayout();
            this.panel9.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox txtGETSchemaResult;
        private System.Windows.Forms.Button btnGETSchema;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button btnAuthenticate;
        private System.Windows.Forms.TextBox txtAuthenticateResponse;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.TextBox txtPOSTSelectResponse;
        private System.Windows.Forms.Button btnPOSTSelect;
        private System.Windows.Forms.TabPage tabPage6;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Button btnPOSTRefresh;
        private System.Windows.Forms.TextBox txtPOSTRefreshResponse;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.TextBox txtPOSTUpdateResponse;
        private System.Windows.Forms.Button btnPOSTUpdate;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.TextBox txtPOSTAddResponse;
        private System.Windows.Forms.Button btnPOSTInsert;
        private System.Windows.Forms.TabPage tabPage7;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.TextBox txtPOSTMIMEResponse;
        private System.Windows.Forms.Button btnPostMimeSelect;
        private System.Windows.Forms.TabPage tabPage8;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.TextBox txtPOSTINSERTMIMEResponse;
        private System.Windows.Forms.Button btnPostMimeInsert;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtClientId;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtBaseURL;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtClientSecret;
        private System.Windows.Forms.ErrorProvider errorProvider1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtMIMEEntityName;
        private System.Windows.Forms.FolderBrowserDialog folderBrowserDialog1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtMIMEInsertEntityName;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
    }
}

