﻿using Newtonsoft.Json;
using System;

namespace CSS_API.DemoApp.Domain
{
    public class OAuthToken
    {
        [JsonProperty("access_token")]
        public string AccessToken { get; set; }

        [JsonProperty("token_type")]
        public string TokenType { get; set; }

        [JsonProperty("expires_in")]
        public int ExpiresIn { get; set; }

        [JsonProperty("refresh_token")]
        public string RefreshToken { get; set; }

        [JsonProperty("as:client_id")]
        public string ClientId { get; set; }

        [JsonProperty("as:refresh_token_life_time")]
        public string RefreshTokenLifeTime { get; set; }

        [JsonProperty(".issued")]
        public DateTime IssuedAt { get; set; }

        [JsonProperty(".expires")]
        public DateTime ExpiresAt { get; set; }
    }
}
