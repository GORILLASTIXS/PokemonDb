﻿namespace CSS_API.DemoApp.Domain
{
    public class SchemaInfo
    {
        public string Name { get; set; }
        public bool IsPrimaryKey { get; set; }
        public bool IsIdentity { get; set; }
        public bool IsNullable { get; set; }
        public string DBType { get; set; }
        public int? MaxLength { get; set; }
        public int? DataPrecision { get; set; }
        public int? DataScale { get; set; }
        public bool HasDefaultValue { get; set; }
    }
}
