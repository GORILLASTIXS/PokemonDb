﻿using System.Collections.Generic;

namespace CSS_API.DemoApp.Domain
{
    public class AddRequest
    {
        public List<AddTuple> Tuples { get; set; } = new List<AddTuple>();
    }

    public class AddTuple
    {
        public string Name { get; set; }
        public object Value { get; set; }
    }
}
