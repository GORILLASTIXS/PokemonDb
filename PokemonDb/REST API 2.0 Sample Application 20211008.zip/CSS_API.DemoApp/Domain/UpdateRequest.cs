﻿using System.Collections.Generic;

namespace CSS_API.DemoApp.Domain
{
    public class UpdateRequest
    {
        public ClauseRule Clause { get; set; } = new ClauseRule();
        public List<UpdateTuple> Tuples { get; set; } = new List<UpdateTuple>();
        public bool TriggerWorkflow { get; set; } = true;
    }

    public class UpdateTuple
    {
        public string Name { get; set; }
        public object Value { get; set; }
    }
}
