﻿using System.Collections.Generic;

namespace CSS_API.DemoApp.Domain
{
    public class SelectQuery
    {
        public List<SelectField> Fields { get; set; } = new List<SelectField>();
        public ClauseRule Clause { get; set; }
        public OrderBy OrderByTag { get; set; } = new OrderBy();
        public List<string> GroupByTag { get; set; } = new List<string>();
        public int? StartIndex { get; set; }
        public int? Length { get; set; }
    }

    public class SelectField
    {
        public string Attribute { get; set; }
        public string Alias { get; set; }
    }

    public class ClauseRule
    {
        public string Condition { get; set; }
        public string Field { get; set; }
        public string Id { get; set; }
        public string Input { get; set; }
        public string Operator { get; set; }
        public List<ClauseRule> Rules { get; set; }
        public string Type { get; set; }
        public object Value { get; set; }
    }

    public class OrderBy
    {
        public List<string> Fields { get; set; } = new List<string>();
        public string Direction { get; set; }
    }
}
